const express = require("express");
const fs = require("fs");
const cors = require("cors");
const bodyParser = require("body-parser");

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(bodyParser.json());

// Load seat data from file
const getSeatData = () => {
  const data = fs.readFileSync("data.json");
  return JSON.parse(data);
};

const saveSeatData = (data) => {
  fs.writeFileSync("data.json", JSON.stringify(data, null, 2));
};

// API to get all seats
app.get("/seats", (req, res) => {
  const data = getSeatData();
  res.json(data.seats);
});

// API to book seats
app.post("/book", (req, res) => {
  const { numberOfSeats } = req.body;
  const data = getSeatData();
  let bookedCount = 0;

  for (let seat of data.seats) {
    if (seat.status === "available" && bookedCount < numberOfSeats) {
      seat.status = "booked";
      bookedCount++;
    }
  }

  if (bookedCount < numberOfSeats) {
    return res.status(400).json({ message: "Not enough seats available!" });
  }

  saveSeatData(data);
  res.json({ message: `${bookedCount} seat(s) booked successfully!` });
});

// Start server
app.listen(PORT, () => {
  console.log(`Server is running on http://localhost:${PORT}`);
});
