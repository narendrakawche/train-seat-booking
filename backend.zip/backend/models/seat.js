const mongoose = require("mongoose");

// Define the schema
const seatSchema = new mongoose.Schema({
  id: { type: Number, required: true, unique: true },
  status: {
    type: String,
    enum: ["available", "booked"],
    default: "available",
  },
});

// Create the model
const Seat = mongoose.model("Seat", seatSchema);

// Export the model
module.exports = Seat;
